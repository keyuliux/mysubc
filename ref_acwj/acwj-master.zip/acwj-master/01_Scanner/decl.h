
// Function prototypes for all compiler files
// Copyright (c) 2019 Warren Toomey, GPL3
int scan(struct token *t);
