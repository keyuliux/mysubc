#ifndef extern_
 #define extern_ extern
#endif

// Global variables
// Copyright (c) 2019 Warren Toomey, GPL3

extern_ int     	Line;
extern_ int		Putback;
extern_ FILE		*Infile;
extern_ FILE		*Outfile;
extern_ struct token	Token;
