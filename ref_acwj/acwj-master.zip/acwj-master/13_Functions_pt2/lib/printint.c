#include <stdio.h>
void printint(long x) {
  printf("%ld\n", x);
}
