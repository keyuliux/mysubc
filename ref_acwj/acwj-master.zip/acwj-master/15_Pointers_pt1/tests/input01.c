void main()
{ printint(12 * 3);
  printint(18 - 2 * 4);
  printint(1 + 2 + 9 - 5/2 + 3*5);
}
