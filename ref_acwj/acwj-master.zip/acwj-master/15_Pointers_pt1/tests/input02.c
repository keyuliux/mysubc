void main()
{
  int fred;
  int jim;
  fred= 5;
  jim= 12;
  printint(fred + jim);
}
