void main()
{
  int x;
  x= 7 < 9;  printint(x);
  x= 7 <= 9; printint(x);
  x= 7 != 9; printint(x);
  x= 7 == 7; printint(x);
  x= 7 >= 7; printint(x);
  x= 7 <= 7; printint(x);
  x= 9 > 7;  printint(x);
  x= 9 >= 7; printint(x);
  x= 9 != 7; printint(x);
}
