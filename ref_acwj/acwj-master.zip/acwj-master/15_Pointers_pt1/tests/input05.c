void main()
{
  int i; int j;
  i=6; j=12;
  if (i < j) {
    printint(i);
  } else {
    printint(j);
  }
}
