void main()
{
  int i; char j;

  j= 20; printint(j);
  i= 10; printint(i);

  for (i= 1;   i <= 5; i= i + 1) { printint(i); }
  for (j= 253; j != 2; j= j + 1) { printint(j); }
}
